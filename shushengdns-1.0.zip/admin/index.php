<?php
/**
 * Created by PhpStorm.
 * User: 快乐是福<815856515@qq.com>
 * Date: 2017/6/4
 * Time: 11:20
 */
header("Location: /index.php/index/admin/index.html");
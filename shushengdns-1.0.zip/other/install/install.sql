-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017-07-06 17:02:29
-- 服务器版本: 5.5.54
-- PHP 版本: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `cs002`
--

-- --------------------------------------------------------

--
-- 表的结构 `pre_configs`
--

CREATE TABLE IF NOT EXISTS `pre_configs` (
  `vkey` varchar(255) NOT NULL,
  `value` varchar(1000) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`vkey`),
  UNIQUE KEY `vkey` (`vkey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `pre_configs`
--

INSERT INTO `pre_configs` (`vkey`, `value`, `remark`) VALUES
('index_title', '书生二级域名分发-1.0', '首页标题'),
('keywords', '书生二级域名分发', 'SEO关键词'),
('description', '书生二级域名分发', 'SEO描述'),
('record_coin', '10', '每条记录需要金币'),
('reg_coin', '50', '注册赠送金币'),
('admin', 'admin', '管理员账号'),
('password', '91d0ce90989fbfa1d92d1e37455f9873', '管理员密码'),
('name', '书生二级域名分发', '网站名称'),
('hold_rr', 'www,wap,3g,m,4g', '域名保留前缀'),
('version', '1.0', '版本号'),
('foot', '<footer class="footer bg-faded mt-3 p-2"><p class="text-center">Powered by <a href="http://www.shusheng.me" target="_blank">网络书生</a> v1.0</p></footer>', '前台底部代码'),
('index_head', '<div class="row"><div class="col-xl-12"><div class="breadcrumb mt-2"><h1 class="display-5">书生二级域名分发系统</h1><p class="lead">好用、简单、免费的二级域名分发系统-网络书生 Shusheng.Me</p></div></div></div>', '首页顶部代码');

-- --------------------------------------------------------

--
-- 表的结构 `pre_dns_apis`
--

CREATE TABLE IF NOT EXISTS `pre_dns_apis` (
  `dns` varchar(30) NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `lines` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `pre_domains`
--

CREATE TABLE IF NOT EXISTS `pre_domains` (
  `domain_id` varchar(50) NOT NULL,
  `domain` varchar(50) NOT NULL,
  `dns` varchar(50) NOT NULL,
  `power` int(11) NOT NULL DEFAULT '0',
  `add_time` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_records`
--

CREATE TABLE IF NOT EXISTS `pre_records` (
  `uid` int(11) NOT NULL,
  `record_id` varchar(50) NOT NULL,
  `domain_id` varchar(50) NOT NULL,
  `rr` varchar(15) NOT NULL,
  `type` varchar(10) NOT NULL,
  `value` varchar(50) NOT NULL,
  `line` tinyint(5) DEFAULT '0',
  `line_name` varchar(50) NOT NULL,
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`record_id`),
  UNIQUE KEY `record_info` (`record_id`,`domain_id`),
  KEY `uid_record_id` (`uid`,`record_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `pre_users`
--

CREATE TABLE IF NOT EXISTS `pre_users` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(16) NOT NULL,
  `pwd` varchar(32) NOT NULL,
  `sid` varchar(32) NOT NULL,
  `group` int(11) NOT NULL DEFAULT '1',
  `coin` int(11) NOT NULL DEFAULT '0',
  `add_time` datetime DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1000 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
